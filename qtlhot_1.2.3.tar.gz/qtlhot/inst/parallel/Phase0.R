#########################################
## PHASE 0: Pre-Initiation.
##          Fast. Run on scheduler?
##
## Set up cross object if none provided.
##
## Output files:
##       cross.RData
##       params.txt
##

library(qtlhot)
qtlhot.phase0(dirpath=".")
